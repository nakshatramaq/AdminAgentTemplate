# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "b87c684f-6cc7-4782-9ed9-3030b3f58b71",
# META       "default_lakehouse_name": "FabricAdminAgent",
# META       "default_lakehouse_workspace_id": "1ea96d33-ced1-48f0-9098-ed7e13bdc625",
# META       "known_lakehouses": [
# META         {
# META           "id": "b87c684f-6cc7-4782-9ed9-3030b3f58b71"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Imports

# CELL ********************

import pyspark.sql.functions as F
from pyspark.sql import Window
from datetime import datetime
from azure.identity import ClientSecretCredential
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, TimestampType, BooleanType

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# #  Configuration

# CELL ********************

kustoUri = "https://trd-zfmmx5us1trradc09u.z1.kusto.fabric.microsoft.com"
kustoQuery = "['ConfigTable'] | where ConfigCategory in ('FUAMConfig') and IsActive == true"
database = "FabricAdminAgentLogs"
accessToken = mssparkutils.credentials.getToken(kustoUri)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

config_df = spark.read\
    .format("com.microsoft.kusto.spark.synapse.datasource")\
    .option("accessToken", accessToken)\
    .option("kustoCluster", kustoUri)\
    .option("kustoDatabase", database)\
    .option("kustoQuery", kustoQuery).load()

config_dict = {row['ConfigKey']: row['ConfigValue'] for row in config_df.collect()}
workspace_id = config_dict.get('WorkspaceId')     
lakehouse_id = config_dict.get('LakehouseId')

if not all([workspace_id,lakehouse_id]):
    raise ValueError("Missing required configuration values. Please check ConfigTable in Kusto.")

print(f"Configuration loaded")


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ==============================
# CONSTRUCT ABFS PATHS
# ==============================
base_abfs_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables"

# Define all ABFS paths for tables
abfs_paths = {
    "capacities": f"{base_abfs_path}/capacities",
    "workspaces": f"{base_abfs_path}/workspaces"
}

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

sql_server_name= "2kg5tzezshsufoul3i7hmpw6fy-gnw2shwrz3yereey5v7bhpogeu.database.fabric.microsoft.com,1433"
sql_database_name= "FabricAdminAgentDB-25b887b8-c219-46fd-8874-221ea1101f63"

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Clean up SQL Server name - remove port if present
sql_server_clean = sql_server_name.split(',')[0] if ',' in sql_server_name else sql_server_name

# Construct JDBC URL - Port 1433 is specified in the connection string
jdbc_url = f"jdbc:sqlserver://{sql_server_clean}:1433;database={sql_database_name};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"

print(f"\nConnecting to: {jdbc_url}")

# Get access token for SQL Database authentication
sql_resource = "https://database.windows.net/"
access_token = mssparkutils.credentials.getToken(sql_resource)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Action Mapping

# CELL ********************

actions_map = {
  "High CU Consuming Workspace": [
    "Notify Workspace Admins"
  ],
  "Orphan Workspace": [
    "Notify Workspace Admins",
    "Delete Workspace"
  ],
  "Unused Workspace": [
    "Notify Workspace Admins",
    "Delete Workspace"
  ],
  "Orphan Report": [
    "Notify Owner",
    "Delete Report"
  ],
  "Unused Report": [
    "Notify Owner",
    "Delete Report"
  ],
  "Orphan Dataset": [
    "Notify Owner",
    "Delete Dataset"
  ],
  "Unused Dataset": [
    "Notify Owner",
    "Delete Dataset"
  ],
  "Outlier Item": [
    "Notify Owner"
  ],
  "Slow Running Dataset": [
    "Notify Owner",
    "Disable Refresh"
  ]
}

# Convert dict to DF
actions_df = spark.createDataFrame(
    [(k, v) for k, v in actions_map.items()],
    ["Finding", "SuggestedActions"]
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Loading lakehouse tables

# CELL ********************

workspaces_cu_consumption = spark.read.table("dbo.workspace_level_cu_consumption")
outlier_items = spark.read.table("dbo.outlier_items")
orphan_unused_workspaces = spark.read.table("dbo.orphan_unused_workspaces")
orphan_unused_reports = spark.read.table("dbo.orphan_unused_reports")
orphan_unused_datasets = spark.read.table("dbo.orphan_unused_datasets")
datasetrefreshanalysis = spark.read.table("dbo.datasetrefreshanalysis")
suggested_actions_settings = spark.read.table("dbo.SuggestedActionsSettings")
event_history = spark.read.table("dbo.EventHistory")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# # Read capacity-related tables from FUAM_Lakehouse
# workspaces_capacity = spark.read.table("FUAM_Lakehouse.dbo.workspaces").select("WorkspaceName", "CapacityId")
# capacities = spark.read.table("FUAM_Lakehouse.dbo.capacities").select("CapacityId", F.col("displayName").alias("CapacityName"))

workspaces_capacity = (
    spark.read.format("delta")
    .load(abfs_paths["workspaces"])
    .select("WorkspaceName", "CapacityId")
)

capacities = (
    spark.read.format("delta")
    .load(abfs_paths["capacities"])
    .select("CapacityId", F.col("displayName").alias("CapacityName"))
)

print("Tables successfully loaded from ABFS paths.")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Findings

# CELL ********************

# ----------------- Findings Extraction -----------------
# 1. High CU Consuming Workspace (using HighCUFlag)
high_cu_df = (
    workspaces_cu_consumption
    .filter(F.col("HighCUFlag") == 1)
    .select("WorkspaceName")
    .withColumn("ArtifactName", F.lit("-"))
    .withColumn("Finding", F.lit("High CU Consuming Workspace"))
    .withColumn("ArtifactType", F.lit("-"))
)

# 2. Outlier Items
outlier_df = (
    outlier_items
    .withColumn("rank", F.row_number().over(Window.orderBy(F.col("Outlier_Factor").desc())))
    .filter(F.col("rank") <= 5)
    .select("WorkspaceName", F.col("ItemName").alias("ArtifactName"), F.col("ItemKind").alias("ArtifactType"))
    .withColumn("Finding", F.lit("Outlier Item"))
)

# 3. Unused Workspace
unused_ws_df = (
    orphan_unused_workspaces
    .filter(F.col("IsUnused") == 1)
    .select("WorkspaceName")
    .withColumn("ArtifactName", F.lit("-"))
    .withColumn("Finding", F.lit("Unused Workspace"))
    .withColumn("ArtifactType", F.lit("-"))
)

# 4. Orphan Workspace
orphan_ws_df = (
    orphan_unused_workspaces
    .filter(F.col("IsOrphan") == 1)
    .select("WorkspaceName")
    .withColumn("ArtifactName", F.lit("-"))
    .withColumn("Finding", F.lit("Orphan Workspace"))
    .withColumn("ArtifactType", F.lit("-"))
)

# 5. Unused Report
unused_reports_df = (
    orphan_unused_reports
    .filter(F.col("IsUnused") == 1)
    .select("WorkspaceName", "ReportName")
    .withColumnRenamed("ReportName", "ArtifactName")
    .withColumn("Finding", F.lit("Unused Report"))
    .withColumn("ArtifactType", F.lit("Report"))
)

# 6. Orphan Report
orphan_reports_df = (
    orphan_unused_reports
    .filter(F.col("IsOrphan") == 1)
    .select("WorkspaceName", "ReportName")
    .withColumnRenamed("ReportName", "ArtifactName")
    .withColumn("Finding", F.lit("Orphan Report"))
    .withColumn("ArtifactType", F.lit("Report"))
)

# 7. Orphan Dataset
orphan_ds_df = (
    orphan_unused_datasets
    .filter(F.col("IsOrphan") == 1)
    .select("WorkspaceName", F.col("DatasetName").alias("ArtifactName"))
    .withColumn("Finding", F.lit("Orphan Dataset"))
    .withColumn("ArtifactType", F.lit("SemanticModel"))
)

# 8. Unused Dataset
unused_ds_df = (
    orphan_unused_datasets
    .filter(F.col("IsUnused") == 1)
    .select("WorkspaceName", F.col("DatasetName").alias("ArtifactName"))
    .withColumn("Finding", F.lit("Unused Dataset"))
    .withColumn("ArtifactType", F.lit("SemanticModel"))
)

# 9. Slow Running Dataset (based on Status column)
slow_ds_df = (
    datasetrefreshanalysis
    .filter(F.col("Status") == "Slow")
    .select("WorkspaceName", F.col("Dataset_Name").alias("ArtifactName"))
    .withColumn("Finding", F.lit("Slow Running Dataset"))
    .withColumn("ArtifactType", F.lit("SemanticModel"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ----------------- Union All Findings -----------------
findings_df = (
    high_cu_df
    .unionByName(outlier_df, allowMissingColumns=True)
    .unionByName(unused_ws_df, allowMissingColumns=True)
    .unionByName(orphan_ws_df, allowMissingColumns=True)
    .unionByName(unused_reports_df, allowMissingColumns=True)
    .unionByName(orphan_reports_df, allowMissingColumns=True)
    .unionByName(orphan_ds_df, allowMissingColumns=True)
    .unionByName(unused_ds_df, allowMissingColumns=True)
    .unionByName(slow_ds_df, allowMissingColumns=True)
)

findings_df = findings_df.filter(
    ~(
        F.lower(F.col("WorkspaceName")).contains("my workspace") |
        F.lower(F.col("WorkspaceName")).contains("personal")
    )
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ----------------- Join with Capacity Information -----------------
# First join with workspaces to get CapacityId
findings_df = findings_df.join(workspaces_capacity, "WorkspaceName", "left")

# Then join with capacities to get CapacityDisplayName
findings_df = findings_df.join(capacities, "CapacityId", "left")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# ----------------- Join with Actions -----------------
final_df = (
    findings_df
    .join(actions_df, "Finding", "left")
    .withColumn("State", F.expr("transform(SuggestedActions, x -> 'none')"))
    .withColumn(
        "Category",
        F.when(F.col("Finding").like("%CU%"), "capacity_optimization")
         .when(F.col("Finding").like("%Slow%"), "performance")
         .otherwise("governance")
    )
    .withColumn("LastUpdatedAt", F.lit(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

# Add row numbers as Id
window = Window.orderBy(F.monotonically_increasing_id())
final_df = final_df.withColumn("Id", F.row_number().over(window))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

final_df = final_df.select(
     "Id","Category", "WorkspaceName", "CapacityId", "CapacityName",
    "ArtifactName", "ArtifactType", "Finding", "SuggestedActions", "State", "LastUpdatedAt"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # IsNewFinding column logic

# CELL ********************

# Create composite key for current findings
current_findings_with_key = final_df.withColumn(
    "FindingKey",
    F.concat_ws("||", F.col("Finding"), F.col("WorkspaceName"), F.col("ArtifactName"))
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

try:
    previous_findings = spark.read \
        .format("jdbc") \
        .option("url", jdbc_url) \
        .option("dbtable", "fabricfinding") \
        .option("accessToken", access_token) \
        .load()
    
    print(f"✓ Successfully read {previous_findings.count()} previous findings from SQL Database")
    
    # Create composite key for previous findings
    previous_keys = previous_findings.select(
        F.concat_ws("||", F.col("Finding"), F.col("WorkspaceName"), F.col("ArtifactName")).alias("PreviousKey")
    ).distinct()
    
    # Mark findings as new or existing
    final_df = current_findings_with_key.join(
        previous_keys,
        current_findings_with_key.FindingKey == previous_keys.PreviousKey,
        "left"
    ).withColumn(
        "IsNewFinding",
        F.when(F.col("PreviousKey").isNull(), 1).otherwise(0)
    ).drop("FindingKey", "PreviousKey")
    
    # Count new findings
    new_count = final_df.filter(F.col("IsNewFinding") == 1).count()
    existing_count = final_df.filter(F.col("IsNewFinding") == 0).count()
    
    print(f"Compared with previous findings:")
    print(f"  - New findings: {new_count}")
    print(f"  - Existing findings: {existing_count}")
    
except Exception as e:
    # If table doesn't exist or error reading, mark all as new
    print(f"Previous findings not found or error: {str(e)[:200]}")
    print("Marking all findings as new")
    final_df = current_findings_with_key.withColumn("IsNewFinding", F.lit(1)).drop("FindingKey")

final_df = final_df.select(
    "Id","Category", "WorkspaceName", "CapacityId", "CapacityName",
    "ArtifactName", "ArtifactType", "Finding", "SuggestedActions", "State", "LastUpdatedAt", "IsNewFinding"
)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

final_df_sql = final_df \
    .withColumn("SuggestedActions", F.to_json(F.col("SuggestedActions"))) \
    .withColumn("State", F.to_json(F.col("State"))) 

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(final_df_sql)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # writing to sql db

# CELL ********************

final_df_sql.write \
    .format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", "dbo.fabricfinding") \
    .option("accessToken", access_token) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .mode("overwrite") \
    .save()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# MARKDOWN ********************

# # Writing to kql db

# CELL ********************

# ----------------- Write to KQL Database (APPEND ONLY NEW FINDINGS) -----------------
print(f"\nProcessing KQL Database insert...")

# Filter only new findings for KQL
new_findings_df = final_df.filter(F.col("IsNewFinding") == 1)
new_findings_count = new_findings_df.count()

if new_findings_count > 0:
    # Add SnapshotTimestamp for KQL
    snapshot_timestamp = datetime.now()
    new_findings_kql = new_findings_df.withColumn(
        "SnapshotTimestamp", 
        F.lit(snapshot_timestamp)
    )
    new_findings_kql = new_findings_kql.withColumn("IsNewFinding", F.col("IsNewFinding").cast("boolean"))
    # Prepare data for KQL (keep boolean as-is, KQL supports bool type)
    new_findings_kql = new_findings_kql \
        .withColumn("SuggestedActions", F.to_json(F.col("SuggestedActions"))) \
        .withColumn("State", F.to_json(F.col("State"))) \
        .withColumn("LastUpdatedAt", F.to_timestamp(F.col("LastUpdatedAt")))
    
    new_findings_kql = new_findings_kql.select(
        "Id","Category", "WorkspaceName", "CapacityId", "CapacityName",
        "ArtifactName", "ArtifactType", "Finding", "SuggestedActions", 
        "State", "LastUpdatedAt", "IsNewFinding", "SnapshotTimestamp"
    )
    
    # Write to KQL using append mode
    try:
        new_findings_kql.write \
            .format("com.microsoft.kusto.spark.synapse.datasource") \
            .option("kustoCluster", kustoUri) \
            .option("kustoDatabase", database) \
            .option("kustoTable", "FabricFindings") \
            .option("accessToken", accessToken) \
            .option("tableCreateOptions", "CreateIfNotExist") \
            .mode("append") \
            .save()
        
        print(f"Successfully appended {new_findings_count} NEW findings to KQL FabricFindings table!")
        print(f"   Kusto Cluster: {kustoUri}")
        print(f"   Kusto Database: {database}")
        print(f"   Snapshot Timestamp: {snapshot_timestamp}")
    except Exception as e:
        print(f"Error writing to KQL Database: {str(e)}")
        raise
else:
    print(f"No new findings to insert into KQL Database")
    print(f"   All {final_df.count()} findings already exist")

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
